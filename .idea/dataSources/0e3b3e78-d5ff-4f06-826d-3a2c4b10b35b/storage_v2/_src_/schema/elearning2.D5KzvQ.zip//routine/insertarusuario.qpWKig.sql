create procedure insertarUsuario(IN nombre_in   varchar(250), IN email_in varchar(30), IN password_in varchar(30),
                                 IN genero_in   varchar(10), IN pais_in varchar(100), IN fecha_ult_ingre_in datetime,
                                 IN ip_in       varchar(12), IN os_in varchar(10), IN navegador_in varchar(20),
                                 IN lenguaje_in varchar(10))
  BEGIN
    INSERT INTO usuario (nombre,email, password, rol, genero, pais,fecha_ultimo_ingreso,ip, os, navegador, lenguaje) 
			VALUES (nombre_in, email_in, password_in, 5, genero_in, pais_in, fecha_ult_ingre_in, ip_in, os_in, navegador_in, lenguaje_in );
  END;

