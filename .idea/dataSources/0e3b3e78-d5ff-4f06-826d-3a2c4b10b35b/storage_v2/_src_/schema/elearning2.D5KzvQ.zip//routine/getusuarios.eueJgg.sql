create procedure getUsuarios()
  BEGIN
    SELECT nombre,email, password, rol, genero, pais,fecha_ultimo_ingreso,ip, os, navegador, lenguaje from usuario; 
  END;

