create procedure getUsuario(IN identificacion_in varchar(30))
  BEGIN
    SELECT nombre,email, password, rol, genero, pais,fecha_ultimo_ingreso,ip, os, navegador, lenguaje from usuario
    where identificacion = identificacion_in; 
  END;

